#!/usr/bin/env bash
set -e

# Tunggu MySQL (sederhana)
if command -v mysqladmin >/dev/null 2>&1; then
  until (echo > /dev/tcp/mysql/3306) >/dev/null 2>&1; do
  echo "Waiting for mysql..."
  sleep 2
  done
fi

cd /var/www/html

# DETEKSI: kalau belum ada artisan → buat project baru (aman meski folder tidak kosong)
if [ ! -f "artisan" ]; then
  echo "Creating new Laravel project..."
  composer create-project laravel/laravel /tmp/laravel
  shopt -s dotglob
  mkdir -p /var/www/html
  mv /tmp/laravel/* /var/www/html/
  rmdir /tmp/laravel
fi

# Install deps kalau vendor belum ada
[ -d "vendor" ] || composer install

# Siapkan .env & APP_KEY
[ -f ".env" ] || cp .env.example .env || true
php artisan key:generate || true

# Permission dasar
chown -R www-data:www-data /var/www/html
find storage bootstrap/cache -type d -exec chmod 775 {} \; || true

exec apache2-foreground
